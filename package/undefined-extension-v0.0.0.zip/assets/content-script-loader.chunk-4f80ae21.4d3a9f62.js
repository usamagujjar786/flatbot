(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-4f80ae21.js")
    );
  })().catch(console.error);

})();
